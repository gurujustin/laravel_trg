@extends('layouts.app')
@section('content')
<div class="manage-booking">
    <div class="container">
        <div class="header">
            <div class="row">
                <div class="col-md-12 col-lg-10 col-lg-offset-1">
                    <h1 class="text-main-color">Manage My Booking</h1>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection