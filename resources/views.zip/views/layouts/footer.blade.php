<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js"></script>
<script src="https://d3umsy5q8nmee6.cloudfront.net/js/app.js?1610442382"></script>
<footer>
    <script src="all.js"></script>
    <div class="row">
        <div class="col-md-1">
            <h5>Company</h5>
        </div>
        <div class="col-md-3">
            <ul>
                <li>
                    <a href="{{route('contact')}}">Contact WeFix</a>
                </li>
                <li>
                    <a href="">About WeFix</a>
                </li>
                <li>
                    <a href="">Vans</a>
                </li>
                <li>
                    <a href="">WeFix BLog</a>
                </li>
                <li>
                    <a href="">FAQS</a>
                </li>
                <li>
                    <a href="">Klarna Payments</a>
                </li>
                <li>
                    <a href="">Terms & Conditions</a>
                </li>
                <li>
                    <a href="">Privacy Policy</a>
                </li>
            </ul>
        </div>
        <div class="col-md-4 social">
            <h5>Follow Us</h5>
            <ul>
                <li>
                    <a href="">
                        <img src="imgs/fb-lgrey.png" alt="Facebook">
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="imgs/tw-lgrey.png" alt="Twitter">
                    </a>
                </li>
            </ul>
        </div>
        <div class="col-md-4 logo">
            <img src="imgs/wefix-logo-no-bg.svg" alt="WeFix">
        </div>
        <div class="col-md-12 subfooter">
            <p>Copyright © 2021 WeFix. All Rights Reserved. Company Registration No: 8100373.</p>
        </div>
    </div>
</footer>